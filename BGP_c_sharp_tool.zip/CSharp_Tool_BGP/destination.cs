﻿using System;

public class pins
{
    public pins()
	{
        string Destination_IP;

        //set get //plaplaplpal
    }
}
